for i in range(1, 13, 1):
    for j in range(1, 13, 1):
        print(str(i) + " X " + str(j) + " = " + str(i*j))